# ACC Business Administration AAS Program Profile

This reference preserves information from the original user-provided skill. It may be outdated and must not replace current official ACC degree requirements or advising.

## Program snapshot

- Program: Business Administration AAS
- Total credits listed: 60
- Suggested duration: 2 years / 4 semesters
- Minimum GPA listed: 2.0
- Expected graduation listed in the original file: Spring 2026

## Requirement categories listed

- General Education: 15 credits
- Core Business: 24 credits
- Electives: 21 credits

## Example courses listed

- ACCT 1011: Financial Accounting I — 4 credits
- ACCT 1012: Managerial Accounting II — 4 credits
- HIST 1302: American History II — 3 credits
- ENGL 1301: Composition I — 3 credits
- MATH 1314: College Algebra — 4 credits
- ITSC 1301: Business Information Systems — 3 credits
- MGMT 1319: Business & Society — 3 credits
- MKTG 1311: Introduction to Marketing — 3 credits
- ECON 2301: Microeconomics — 3 credits

## Textbooks and learning resources listed

- Horngren's Financial & Managerial Accounting for ACCT 1011
- American Stories: A History of the United States, Volume 2 for HIST 1302
- Connect Online Access for Business Information Systems for ITSC 1301

## Study techniques

- Active Recall: test yourself without looking at notes.
- Spaced Repetition: review at increasing intervals such as 1, 3, 7, 14, and 30 days.
- Feynman Technique: explain a concept simply to identify gaps.
- Interleaving: mix related problem types or topics.
- Cornell Notes: organize notes into cues, details, and summary.
- Pomodoro: use focused work intervals with short breaks.

## Subject coverage from the original skill

### Accounting

Journal entries, double-entry bookkeeping, ledgers, trial balances, financial statements, depreciation, accrual accounting, debit and credit rules, income statements, balance sheets, assets, liabilities, and equity.

### History

Civil War, Reconstruction, Manifest Destiny, Industrial Revolution, emancipation, American expansion, and social change.
